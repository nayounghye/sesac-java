package _02_control_statement;

import java.util.Scanner;

public class Prac4 {
    public static void main(String[] args) {
        System.out.println("=== 실습4. 메소드 ===");

        MethodOverloading ol = new MethodOverloading();
        Scanner sc = new Scanner(System.in);
        System.out.println("숫자 두 개를 입력하세요.");
        int


        System.out.println(ol.add(num, num2));
        System.out.println(ol.add(num, num2));
        System.out.println(ol.add(num, num2));
    }
    public int add(int a, int b) {return  a + b;}
    public int  minus(int a, int b) {return  a - b;}
    public int division(int a, int b) {return  a / b;}
    public int multiplication(int a, int b) {return  a * b;}
}

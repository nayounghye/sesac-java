package _02_control_statement;

import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;

public class ConditionalStatement {
    public static void main(String[] args) {
        int number = 10;
        if(number % 2 == 0) {
            System.out.println("짝수");
        } else {
            System.out.println("홀수");
        }

        ////////////////////////////////////////////////////////////////////////////
        // 문자열 (String) 객체 비교
        System.out.println("이름을 입력해주세요. >> "); // 죠르디
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine(); // 엔터 이전까지 문자열을 받음!
        System.out.println("name값 확인 : " + name);

        // Bad ('==' 대인 연산자 사용) -> string은 대인 연산자로 적용되지 않으므로 equals 메소드를 사용해야 함.
//        if(name == "죠르디") {
//            System.out.println("환영합니다!");
//        } else {
//            System.out.println("이름을 다시 입력해 주세요!");
//        }

        // Good ('.equals()' 메서드 사용)
        if(name.equals("죠르디")) {
            System.out.println("환영합니다!");
        } else {
            System.out.println("이름을 다시 입력해 주세요!");
        }

        // Why?
        // - "==" 연산자 : 두 객체의 참조를 비교한다. 즉, 동일한 메모리 위치를 가르키는지 확인한다.'
        // - ".equals()" 메서드 : 두 객체의 '내용'이 동일한지 비교한다.

        // 문자열 리터럴의 경우, Java에서 특별한 취급을 해준다.
        // 동일한 문자열 리터럴이 사용되는 경우 Java 컴파일러라는 문자열 풀(string pool)이라는 공유된 메모리 영역에 해당 문자열을 저장한다.
        // 즉 ,아래의 str1, str2은 같은 문자열을 가리키고 있으므로, 같은 참조값을 가진다.
        // 결론적으로 문자열 리터럴로 작성한 경우 ==연산자를 써도,  .equals() 메서드로 써도 같은 결과값이 나온다.
        String str1 = "hello";
        String str2 = "hello";
       if (str1 == str2) {
           System.out.println("같은 참조를 가리킴");
       } else {
           System.out.println("서로 다른 참조를 가리킴");
       }

       if (str1.equals(str2)) {
           System.out.println("내용이 같다");
       } else {
           System.out.println("내용이 다르다");
       }

       // 문자열 "동적 할당"의 경우, new String(...)을 사용해서 새로운 문자열 객체를 생성할 때 -> 서로 다른 객체를 가리킨다.
       // str3, str4는 다른 객체이므로, == 연산자로 비교시 false가 나온다.
       // 따라서 문자열 비교시 (내용비교) 'equals' 메소드를 쓰는 것이 바람직하다.
        String str3 = new String("hi");
        String str4 = new String("hi");
        if (str3 == str4) {
            System.out.println("같은 참조를 가리킴");
        } else {
            System.out.println("서로 다른 참조를 가리킴");
        }

        if (str3.equals(str4)) {
            System.out.println("내용이 같다");
        } else {
            System.out.println("내용이 다르다");
        }

        ////////////////////////////////////////////////////////////////////////////
        // switch ~ case 문
        // - 각 case 문의 break 문 선택 사항, break 문 생략시 바로 밑의 case 문으로 넘어간다.
//        String dayOfWeek;
//        int day = 4;
//
//        switch(day) {
//            case 1:
//                dayOfWeek = "일요일";
//                break;
//            case 2:
//                dayOfWeek = "월요일";
//                break;
//            case 3:
//                dayOfWeek = "화요일";
//                break;
//            case 4:
//            case 5:
//            case 6:
//            case 7:
//                dayOfWeek = "수~토요일";
//                break;
//            default:
//                dayOfWeek = "잘못된 입력입니다.";
//                break;
//        }
//        System.out.println(dayOfWeek);
//    }
        // 위 코드와 동일한 코드이나, 아래 코드가 향상된 Java에서 추천하는 방식!
        String dayOfWeek;
        int day = 4;

        dayOfWeek = switch (day) {
            case 1 -> "일요일";
            case 2 -> "월요일";
            case 3 -> "화요일";
            case 4, 5, 6, 7 -> "수~토요일";
            default -> "잘못된 입력입니다.";
        };
        System.out.println(dayOfWeek);
    }
}
